Navigate to '/home/machinekit/machinekit-dev/configs/ARM/BeagleBone'

DELETE your any 'PocketNC' directory
then copy: 
	PocketNC
	
Should end up with:
	/home/machinekit/machinekit-dev/configs/ARM/BeagleBone/PocketNC/

then from a console type in...
	chmod +x install

then...
	./install