# MendelMax CRAMPS configuration for Machinekit

3D printer configuration using Machinekits Python API for my MendelMax.

This configuration does not use the PRU pin hunting fix. If you want
enable this please take a look at the Fabrikator-Mini-CRAMPS
configuration.
