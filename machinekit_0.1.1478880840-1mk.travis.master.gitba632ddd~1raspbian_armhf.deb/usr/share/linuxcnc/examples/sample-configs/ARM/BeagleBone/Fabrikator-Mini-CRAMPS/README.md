# Fabrikator Mini CRAMPS configuration for Machinekit

3D printer configuration using Machinekits Python API for the Turnigy Fabrikator Mini.
