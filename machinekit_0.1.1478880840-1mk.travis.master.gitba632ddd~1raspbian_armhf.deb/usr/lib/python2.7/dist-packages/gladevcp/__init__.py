from hal_pythonplugin import *
