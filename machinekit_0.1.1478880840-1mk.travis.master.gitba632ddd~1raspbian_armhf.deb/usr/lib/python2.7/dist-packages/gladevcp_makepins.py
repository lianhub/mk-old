# Backward compatible name

import warnings

warnings.warn("gladevcp_makepins name is deprecated. Use gladevcp.makepins instead")

from gladevcp.makepins import *
